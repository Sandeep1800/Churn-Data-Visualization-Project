import streamlit as st
import pandas as pd
from streamlit_pandas_profiling import st_profile_report
from ydata_profiling import profile_report
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import streamlit as st
import numpy as np
import snowflake.connector
# import plotly.figure_factory as ff
import plotly.express as px
import datetime
from PIL import Image


conn = snowflake.connector.connect(**st.secrets['snowflake'],use_openssl_only = False)
with conn.cursor() as cur:
    cur.execute('select * from data')
    res = cur.fetch_pandas_all()
    data = pd.DataFrame(res)
    df=data
    # st.dataframe(data)
 
with conn.cursor() as cur:
    cur.execute('select * from FORECASTED')
    res = cur.fetch_pandas_all()
    fdata = pd.DataFrame(res)
    # st.dataframe(fdata)
    st.set_page_config(
    page_title=" Cogwise.ai",
    page_icon="📊", 
    layout="wide",
    initial_sidebar_state="expanded",)

with st.sidebar:
    st.image("cogwise_logo.png", width=300)
    st.markdown("<h1 style='text-align: left; color: #3498DB;'>AIML Model In Logistics</h1>", unsafe_allow_html=True)
    choice = st.radio('',['KPI','Profiling','MLAAS','Demand Forecasting','Visualization','About'])
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown("<h1 style='text-align: left; color: #3498DB;'>About Cogwise.ai</h1>", unsafe_allow_html=True)
    st.write("""
            We help enterprises reinvent and optimize business functions by establishing the right approach 
            to use generative AI and LLMs to accelerate business value and growth.


            """)
if choice == 'KPI':
    
    
    centered_title = """
        <div style="display: flex; justify-content: center;">
            <h2 style="color: black;">BUSINESS INSIGHTS</h2>
        </div>
    """
    st.markdown(centered_title, unsafe_allow_html=True)
    c1,c2,c3,c4= st.columns(4)
   
    with c1:
        count = len(data)
        st.metric("Shipment", count)

    with c2:
        cost = data['COST'].sum() / 1000000
        formatted_value = "{:.2f}".format(cost)
        cost_str = f"{formatted_value}M"
        st.metric("Cost", cost_str,str(cost_str)+'%')

    with c3:
        profit = data['PROFIT'].sum() / 1000000
        formatted_value = "{:.2f}".format(profit)
        profit_str = f"{formatted_value}M"
        st.metric("Profit", profit_str,str(profit_str)+'%')
        
    with c4:
        revenue = data['REVENUE'].sum() / 1000000
        formatted_value = "{:.0f}".format(revenue)
        # revenue_str = f"{formatted_value}M"
        revenue_str = 100
        st.metric("Revenue",revenue_str,str(revenue_str)+'%')
    
    
    a1,a2=st.columns(2)
    with a1:
        st.text('select Vendoe Group')
        choice = st.radio(' ' , ['Fleet','Non Fleet'])
    with a2:
        st.text('select Location type')
        choice1 = st.radio(' ' , ['O','D'])
    if choice == 'Fleet' and choice1== 'O':
        
        d1 = data[(data['VENDORGROUP']=='Fleet') & (data['LOCTYPE']=='O')]
 
        fig = px.histogram(d1,x=['CUSTSTATE'],color='CUSTCITY',labels = {'value':'States','Count':'Number Of Orders'},title='Number of Orders In Each State')
        st.plotly_chart(fig)
 
        fig0 = px.pie(d1,values='STOP',names='CUSTSTATE',title='Stops In Each State')
        st.plotly_chart(fig0)
 
        fig1 = px.bar(d1,x='CUSTSTATE',y='DELEVERY_DAY',color='STOP',title="Delivery Status For Each State")
        st.plotly_chart(fig1)
 
        fig2 = px.scatter(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        st.plotly_chart(fig2)
        # fig3 = px.bar(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        # st.plotly_chart(fig3)

    if choice == 'Fleet' and choice1== 'D':
        
        d1 = data[(data['VENDORGROUP']=='Fleet') & (data['LOCTYPE']=='D')]
 
        fig = px.histogram(d1,x=['CUSTSTATE'],color='CUSTCITY',labels = {'value':'States','Count':'Number Of Orders'},title='Number of Orders In Each State')
        st.plotly_chart(fig)
 
        fig0 = px.pie(d1,values='STOP',names='CUSTSTATE',title='Stops In Each State')
        st.plotly_chart(fig0)
 
        fig1 = px.bar(d1,x='CUSTSTATE',y='DELEVERY_DAY',color='STOP',title="Delivery Status For Each State")
        st.plotly_chart(fig1)
 
        fig2 = px.scatter(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        st.plotly_chart(fig2)

    if choice == 'Non Fleet' and choice1== 'O':
        
        d1 = data[(data['VENDORGROUP']=='Non-Fleet') & (data['LOCTYPE']=='O')]
 
        fig = px.histogram(d1,x=['CUSTSTATE'],color='CUSTCITY',labels = {'value':'States','Count':'Number Of Orders'},title='Number of Orders In Each State')
        st.plotly_chart(fig)
 
        fig0 = px.pie(d1,values='STOP',names='CUSTSTATE',title='Stops In Each State')
        st.plotly_chart(fig0)
 
        fig1 = px.bar(d1,x='CUSTSTATE',y='DELEVERY_DAY',color='STOP',title="Delivery Status For Each State")
        st.plotly_chart(fig1)
 
        fig2 = px.scatter(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        st.plotly_chart(fig2)
    
    
    if choice == 'Non Fleet' and choice1== 'D':
        
        d1 = data[(data['VENDORGROUP']=='Non-Fleet') & (data['LOCTYPE']=='D')]
 
        fig = px.histogram(d1,x=['CUSTSTATE'],color='CUSTCITY',labels = {'value':'States','Count':'Number Of Orders'},title='Number of Orders In Each State')
        st.plotly_chart(fig)
 
        fig0 = px.pie(d1,values='STOP',names='CUSTSTATE',title='Stops In Each State')
        st.plotly_chart(fig0)
 
        fig1 = px.bar(d1,x='CUSTSTATE',y='DELEVERY_DAY',color='STOP',title="Delivery Status For Each State")
        st.plotly_chart(fig1)
 
        fig2 = px.scatter(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        st.plotly_chart(fig2)

if choice == 'Profiling':
    
    data['ESTIMATED_DELIVARY_TIME'] = pd.to_datetime(data['ESTIMATED_DELIVARY_TIME'])
    data['ACTUAL_DELIVARY_TIME'] = pd.to_datetime(data['ACTUAL_DELIVARY_TIME'])
    profile_report = data.profile_report(minimal=True)
    st_profile_report(profile_report)
    # # Assuming 'data' is your pandas DataFrame
    # data['ESTIMATED_DELIVARY_TIME'] = pd.to_datetime(data['ESTIMATED_DELIVARY_TIME'])
    # data['ACTUAL_DELIVARY_TIME'] = pd.to_datetime(data['ACTUAL_DELIVARY_TIME'])

    # profile_report = ProfileReport(data, minimal=True)
    # st_profile_report(profile_report)

if choice == "MLAAS":  
    st.title('Logistic Classification Prediction') 

    dff=df
    dff.drop(['ID','ESTIMATED_DELIVARY_TIME','ACTUAL_DELIVARY_TIME','COST','REVENUE','PROFIT','DELEVERY_DAY','CUSTCITY','CUSTSERVICEFLAG',
                                'SHIPPERCITY','SHIPPERSTATE','SHIPPERLIVEDROPPOOLFLAG','ORIGRAMPREGIONCODE',
                                        'ORIGGROUNDREGIONCODE','ORIGRSCREGIONCODE','CONSIGNEECITY','CONSIGNEESTATE','CONSIGNEELIVEDROPPOOLFLAG',
                                        'DESTRAMPREGIONCODE','DESTGROUNDREGIONCODE','DESTRSCREGIONCODE','RAMPCITY','RAMPSTATE','RAMPAREA','VENDORGROUP',
                                'PACERCONTROLLED'],axis=1,inplace=True)
        
    dff=df[df.ONTIMEFLAG=='Success'].iloc[0:500]
    dff1=df[df.ONTIMEFLAG=='Fail']
    fdf=pd.concat([dff,dff1],axis=0)
    fdf.reset_index(inplace = True)
    fdf.drop('index',axis=1,inplace=True)

    label_encode_LocType = {value: key for key , value in enumerate(fdf["LOCTYPE"].unique())}
    fdf["LOCTYPE"] = fdf["LOCTYPE"].map(label_encode_LocType)

    # label_encode_Seq = {value: key for key , value in enumerate(fdf["Seq"].unique())}
    # fdf["Seq"] = fdf["Seq"].map(label_encode_Seq)

    # label_encode_Stop = {value: key for key , value in enumerate(fdf["Stop"].unique())}
    # fdf["Stop"] = fdf["Stop"].map(label_encode_Stop)

    # label_encode_SMPFlag = {value: key for key , value in enumerate(fdf["SMPFlag"].unique())}
    # fdf["SMPFlag"] = fdf["SMPFlag"].map(label_encode_SMPFlag)

    label_encode_OrderStatusCode = {value: key for key , value in enumerate(fdf["ORDERSTATUSCODE"].unique())}
    fdf["ORDERSTATUSCODE"] = fdf["ORDERSTATUSCODE"].map(label_encode_OrderStatusCode)

    label_encode_GroundRegionCode = {value: key for key , value in enumerate(fdf["GROUNDREGIONCODE"].unique())}
    fdf["GROUNDREGIONCODE"] = fdf["GROUNDREGIONCODE"].map(label_encode_GroundRegionCode)

    label_encode_RSCRegionCode = {value: key for key , value in enumerate(fdf["RSCREGIONCODE"].unique())}
    fdf["RSCREGIONCODE"] = fdf["RSCREGIONCODE"].map(label_encode_RSCRegionCode)

    label_encode_CustState = {value: key for key , value in enumerate(fdf["CUSTSTATE"].unique())}
    fdf["CUSTSTATE"] = fdf["CUSTSTATE"].map(label_encode_CustState)

    label_encode_CustLiveDropPoolFlag = {value: key for key , value in enumerate(fdf["CUSTLIVEDROPPOOLFLAG"].unique())}
    fdf["CUSTLIVEDROPPOOLFLAG"] = fdf["CUSTLIVEDROPPOOLFLAG"].map(label_encode_CustLiveDropPoolFlag)
    
    fdf['ONTIMEFLAG'] = np.where(fdf['ONTIMEFLAG'] == 'Success' , 0,1)

    X=fdf.drop('ONTIMEFLAG',axis=1)
    Y=fdf['ONTIMEFLAG']

    X_train,X_test,y_train,y_test = train_test_split(X, Y,test_size = 0.2,random_state=10)
    scaler = StandardScaler()
    scaler.fit(X_train)
    transform = scaler.transform(X_train)
    scalar_train = pd.DataFrame(transform)
    scalar_train.head()

    le = LabelEncoder()
    y_train = le.fit_transform(y_train)

    cl_xgb=xgb.XGBClassifier()
    cl_xgb.fit(X_train,y_train,verbose=True,early_stopping_rounds=10,eval_set=[(X_test,y_test)])


    with st.form(key='my_form'):
        LOCTYPE = st.selectbox("LOCTYPE",['O','D']) 
        SEQ = st.selectbox("SEQ",[1,2,3,4,5])
        STOP = st.selectbox("STOP",[1,2,3,4])
        SMPFLAG = st.selectbox("SMPFLAG",[0,1])
        ORDERSTATUSCODE = st.selectbox("ORDERSTATUSCODE",['F', 'L', 'Y', 'S', 'A', 'C']) 
        GROUNDREGIONCODE = st.selectbox("GROUNDREGIONCODE",['SOCA', 'OHV', 'CNMEX', 'EAST', 'SE', 'SW', 'CANADA', 'PNW','NEMEX', 'NOCA', 'SOMEX', 'NWMEX'])
        RSCREGIONCODE = st.selectbox("RSCREGIONCODE",['WESTRSC', 'NORRSC', 'MEXIRSC', 'SOURSC'])

        CUSTSTATE = st.selectbox("CUSTSTATE",['CA', 'OH', 'GJ', 'VA', 'JA', 'GA', 'TX', 'BC', 'IL', 'IN', 'SC',
        'WA', 'PA', 'MD', 'NL', 'AL', 'AR', 'OR', 'CT', 'FL', 'WI', 'NJ',
        'NC', 'ON', 'OK', 'MO', 'MI', 'TM', 'TN', 'SL', 'NY', 'KY', 'CU',
        'EM', 'NH', 'WV', 'MS', 'LA', 'NV', 'IA', 'HG', 'MA', 'KS', 'RI',
        'QE', 'NM', 'DC', 'VT', 'MN', 'UT', 'CI', 'AZ', 'DF', 'AG', 'CO',
        'DE', 'TL', 'ID', 'ZA', 'PB', 'QC', 'AB', 'ME', 'NB'])
        CUSTLIVEDROPPOOLFLAG = st.selectbox("CUSTLIVEDROPPOOLFLAG",['P', 'D', 'L'])

        submit_button = st.form_submit_button(label ='Predict')
    if submit_button:
        d = {'LOCTYPE':label_encode_LocType[LOCTYPE],
            'SEQ':SEQ,
            'STOP':STOP,
            'SMPFLAG':SMPFLAG,   
            'ORDERSTATUSCODE':label_encode_OrderStatusCode[ORDERSTATUSCODE],
            'GROUNDREGIONCODE':label_encode_GroundRegionCode[GROUNDREGIONCODE],
            'RSCREGIONCODE':label_encode_RSCRegionCode[RSCREGIONCODE],
    
            'CUSTSTATE':label_encode_CustState[CUSTSTATE],
            'CUSTLIVEDROPPOOLFLAG':label_encode_CustLiveDropPoolFlag[CUSTLIVEDROPPOOLFLAG]
            }

        dff = pd.DataFrame(d,index = [0])
    # print(dff)
    # print(X[:15])
    # print(cl_xgb.predict(X))
        predictions = cl_xgb.predict(dff[:1])
        print(predictions[0])


        
        if predictions[0]==0:
                st.write("SUCCESS :sunglasses:")
                st.balloons()
        else:
                st.write("FAIL :cry:")



if choice == 'Demand Forecasting':
    centered_title = """
        <div style="display: flex; justify-content: center;">
            <h2 style="color: black;">Demand Forecasting</h2>
        </div>
    """
    st.markdown(centered_title, unsafe_allow_html=True)
    # st.dataframe(fdata)
    ax1,bx2,cx3 = st.tabs(['Annually','Halfyearly','Quaterly']) 

    fdata['DATE'] = pd.to_datetime(fdata['DATE']).dt.date  # Convert to date only
    
    with ax1:
        # if st.button('Annually'):
            start_date = datetime.date(2022, 1, 1)
            end_date = datetime.date(2023, 12, 31)
            fdf = fdata[(fdata['DATE'] >= start_date) & (fdata['DATE'] <= end_date)]
            st.dataframe(fdf)
            fig = px.scatter(fdf,x=['CUSTSTATE'],color='FORECASTED_DEMAND',labels={'value':'States','Count':'FORECASTED DEMAND'},title='FORECASTED DEMAND FOR EACH STATE')
            st.plotly_chart(fig)
            fig = px.bar(fdf,x=['CUSTSTATE'],color='FORECASTED_DEMAND',labels={'value':'States','Count':'FORECASTED DEMAND'},title='FORECASTED DEMAND FOR EACH STATE')
            st.plotly_chart(fig)
            fig = px.histogram(fdf,x=['CUSTSTATE'],color='FORECASTED_DEMAND',labels={'value':'States','Count':'FORECASTED DEMAND'},title='FORECASTED DEMAND FOR EACH STATE')
            st.plotly_chart(fig)
    
    with bx2:
          c = st.selectbox('Select Half-Year',('First Half','Second Half'))
          if c == 'First Half':
    
            start_date = datetime.date(2022, 1, 1)
            end_date = datetime.date(2023, 6, 30)
            fdf = fdata[(fdata['DATE'] >= start_date) & (fdata['DATE'] <= end_date)]
            st.dataframe(fdf)

          elif c == 'Second Half':
            start_date = datetime.date(2023, 7, 30)
            end_date = datetime.date(2023, 12, 31)
            fdf = fdata[(fdata['DATE'] >= start_date) & (fdata['DATE'] <= end_date)]
            st.dataframe(fdf)
    
    with cx3:
        # if st.button('Quarterly'):
            # start_date = datetime.date(2022, 1, 1)
            # end_date = datetime.date(2023, 3, 31)
            # fdf = fdata[(fdata['DATE'] >= start_date) & (fdata['DATE'] <= end_date)]
            # st.dataframe(fdf)
        quarter = st.selectbox('Select Quarter', ('Q1', 'Q2', 'Q3', 'Q4'))
        if quarter == 'Q1':
            start_date = datetime.date(2022, 1, 1)
            end_date = datetime.date(2022, 3, 31)
        elif quarter == 'Q2':
            start_date = datetime.date(2022, 4, 1)
            end_date = datetime.date(2022, 6, 30)
        elif quarter == 'Q3':
            start_date = datetime.date(2022, 7, 1)
            end_date = datetime.date(2022, 9, 30)
        else:  Q4
        start_date = datetime.date(2022, 10, 1)
        end_date = datetime.date(2022, 12, 31)
        fdf = fdata[(fdata['DATE'] >= start_date) & (fdata['DATE'] <= end_date)]
        st.dataframe(fdf)




if choice == 'About':
    # st.snow()
    ca1,ca2 = st.columns(2)
    with ca1:
       
        st.image('logo.jpg',width=166)
        st.markdown('                                 ')
       
        st.markdown("<h2 style='color: black;'>Activate data.</h2>", unsafe_allow_html=True)
        st.markdown("<h2 style='color: black;'>Augment Intelligence.​</h2>", unsafe_allow_html=True)
        st.markdown("<h2 style='color: black;'>Amplify outcomes.​</h2>", unsafe_allow_html=True)
        st.write("""
            We help enterprises reinvent and optimize business functions by establishing the right approach 
            to use generative AI and LLMs to accelerate business value and growth.


            """)
        
   
    with ca2:
        st.image('ab1.jpg',width=587)
    
        centered_title = """
        <div style="display: flex; justify-content: center;">
            <h1 style="color: black;">Our Services</h1>
        </div>
    """
    st.markdown(centered_title, unsafe_allow_html=True)



    abt1,abt2,abt3 = st.columns(3)
    with abt1:
        st.markdown("<h2 style='color: black;'>Generative AI</h2>", unsafe_allow_html=True)
        
        st.write("""
                We help enterprises reinvent and optimize business functions by establishing the right approach 
                to use generative AI and LLMs to accelerate business value and growth.


                """)
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        st.markdown("<h2 style='color: black;'>Why Cogwise?</h2>", unsafe_allow_html=True)
        st.write("""
           We are building Secure Solutions, Reliable Components, Scalable Architectures and Strong Teams.
          At Cogwise, we are committed to help our customers accelerate their AI initiatives and 
          tap into the Generative AI and LLM's Securely, Safely and Swiftly.

                """) 

        st.markdown(' ')
        st.markdown(' ')
        
        st.markdown("<h2 style='color: black;'>Reference Arichitecture</h2>", unsafe_allow_html=True)
        
        st.write("""
        While the whole concept is still in nascent stage, Cogwise built a strong model reference architecture that is the starting point template for all new initiatives. Our strategy is to leverage existing solutions and teams and augment them with our capabilities to build new solutions faster.
            


                """)
    with abt2:
        st.markdown("<h2 style='color: black;'>LLM Development & Integration</h2>", unsafe_allow_html=True)
        
        st.write("""
            Build custom Large Language Models (LLMs) and LLM based solutions that accurately comprehend, generate and process human language


                """) 
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        
        st.markdown("<h2 style='color: black;'>People First Company</h2>", unsafe_allow_html=True)
        
        st.write("""
            We strongly believe Strong Teams and People First Philosophy can deliver great results. Our founding team is Ex-Amazon, Ex-Bloomberg, Ex-Microsoft, Ex-JP Morgan and we will continue to attract amazing talent and are committed to build a strong team


                """)
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
         

        st.markdown("<h2 style='color: black;'>Strong & Growing Repertoire</h2>", unsafe_allow_html=True)
        
        st.write("""
        We are constantly building AI solutions and accelerators that includes transformer models, custom generative AI models, multimodal models, NLP based tools, MLOps Accelerators and more.
            


                """) 
        # st.image("giphy.gif", caption='Your GIF', width=589)

        
        
    with abt3:
        st.markdown("<h2 style='color: black;'>Apps & Integration</h2>", unsafe_allow_html=True)
        
        st.write("""
            Put your business at the forefront of conversational AI. Provide your users/customers with intelligent natural language responses that enhance experience, optimize operations and uncover valuable insights into business needs. 


                """)
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        st.markdown(' ')
        st.markdown("<h2 style='color: black;'>We Care</h2>", unsafe_allow_html=True)
        
        st.write("""
        We care about our society & environment. For Every Full time employee we hire we allot $500 per year for CSR activities.
            


                """)
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ') 
            
    centered_title = """
            <div style="display: flex; justify-content: center;">
                <h1 style="color: black;">Have a look at out Blog</h1>
            </div>
        """
    st.markdown(centered_title, unsafe_allow_html=True)
    centered_text = """
            <div style="display: flex; justify-content: center;">
                <h6 style="color: black;">Have a look at out Blog</h6>
            </div>
        """
    st.markdown(centered_text, unsafe_allow_html=True)
    ani1,ani2,ani3 = st.columns(3)
    with ani1:
        st.image("ani1.gif", caption='')
        st.markdown("[Unlocking the Power of AI: How Cogwise Masters Domain Adaptation with LLMs](https://www.cogwise.ai/post/unlocking-the-power-of-ai-how-cogwise-masters-domain-adaptation-with-llms)")

    with ani2:
        st.image("ani2.gif", caption='')
        st.markdown("[Revolutionizing the Fashion Industry with Stable Diffusion Models and AI](https://www.cogwise.ai/post/revolutionizing-the-fashion-industry-with-stable-diffusion-models-and-ai)")
    with ani3:
        st.image("ani3.gif", caption='')
        st.markdown("[Revolutionizing Flash Sales with AWS: The Future of Digital Commerce](https://www.cogwise.ai/post/revolutionizing-flash-sales-with-aws-the-future-of-digital-commerce)")

    st.markdown(
        """
        <style>
        .footer {
            background-color: lightblue;
            padding: 20px;
             st.markdown("Reach out to us on +1 2233445566. Our team will be happy to help answer your questions.")
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 200px; /* Set the height of the footer */
        }
        .footer-text {
            color: white;
            font-size: 20px;
            font-weight: bold;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Display the colored background with text in the middle
    st.markdown("### Call us")
    st.markdown("Reach out to us on +1 2233445566. Our team will be happy to help answer your questions.")
    st.markdown("")
    st.markdown("### Reach us")
    st.markdown("1234 qwerty Pkwy, Suite 0000")
    st.markdown("GA 30004")
    st.markdown("helloworld@cogwise.ai")
    st.markdown("</div>", unsafe_allow_html=True)

