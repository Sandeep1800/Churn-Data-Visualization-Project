import streamlit as st
import pandas as pd
import ydata_profiling
from ydata_profiling import profile_report
from steamlit_pandas_profiling import st_profile_report
import xgboost as xgb
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
import numpy as np
import snowflake.connector
import plotly.figure_factory as ff
import plotly.express as px

from snowflake.sqlalchemy import URL

conn = snowflake.connector.connect(**st.secrets['snowflake'],use_openssl_only = False)
with conn.cursor() as cur:
    cur.execute('select * from data')
    res = cur.fetch_pandas_all()
    data = pd.DataFrame(res)
    df = data
    # st.dataframe(data)
 

with conn.cursor() as cur:
    cur.execute('select * from FORECASTED')
    res = cur.fetch_pandas_all()
    fdata = pd.DataFrame(res)
    # st.dataframe(fdata)

with st.sidebar:
    st.image("cogwise_logo.png", width=300)
    st.markdown("<h1 style='text-align: left; color: #3498DB;'>AIML Model In Logistics</h1>", unsafe_allow_html=True)
    choice = st.radio('',['KPI','Profiling','MLAAS','Demand Forecasting','Visualization'])
    
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    
    st.markdown("<h1 style='text-align: left; color: #3498DB;'>About Cogwise.ai</h1>", unsafe_allow_html=True)
    st.write("""
            We help enterprises reinvent and optimize business functions by establishing the right approach 
            to use generative AI and LLMs to accelerate business value and growth.


            """)
if choice == 'KPI':
    centered_title = """
        <div style="display: flex; justify-content: center;">
            <h2 style="color: black;">BUSINESS INSIGHTS</h2>
        </div>
    """
    st.markdown(centered_title, unsafe_allow_html=True)

    # st.dataframe(data)

    # st.dataframe(fdata)

    c1,c2,c3,c4= st.columns(4)
   
    with c1:
        count = len(data)
        st.metric("Shipment", count)

    with c2:
        cost = data['COST'].sum() / 1000000
        formatted_value = "{:.2f}".format(cost)
        cost_str = f"{formatted_value}M"
        st.metric("Cost", cost_str)

    with c3:
        profit = data['PROFIT'].sum() / 1000000
        formatted_value = "{:.2f}".format(profit)
        profit_str = f"{formatted_value}M"
        st.metric("Profit", profit_str)
        
    with c4:
        revenue = data['REVENUE'].sum() / 1000000
        formatted_value = "{:.0f}".format(revenue)
        # revenue_str = f"{formatted_value}M"
        revenue_str = 100
        st.metric("Revenue",revenue_str,str(revenue_str)+'%')

    a1,a2,a3,a4 = st.columns(4)
    a1.metric('****Shipment****', len(data))
    a2.metric("****Cost****", str(cost)+'M', str(cost)+'%')
    a3.metric("****Profit****",str(profit)+'M',str(profit)+'%')
    a4.metric("****Revenue****",str(revenue)+'M',str(revenue)+'%')

    a1,a2=st.columns(2)
    with a1:
        st.text('select Vendoe Group')
        choice = st.radio(' ' , ['Fleet','Non Fleet'])
    with a2:
        st.text('select Location type')
        choice1 = st.radio(' ' , ['O','D'])
    if choice == 'Fleet' and choice1== 'O':
        
        d1 = data[(data['VENDORGROUP']=='Fleet') & (data['LOCTYPE']=='O')]
 
        fig = px.histogram(d1,x=['CUSTSTATE'],color='CUSTCITY',labels = {'value':'States','Count':'Number Of Orders'},title='Number of Orders In Each State')
        st.plotly_chart(fig)
 
        fig0 = px.pie(d1,values='STOP',names='CUSTSTATE',title='Stops In Each State')
        st.plotly_chart(fig0)
 
        fig1 = px.bar(d1,x='CUSTSTATE',y='DELEVERY_DAY',color='STOP',title="Delivery Status For Each State")
        st.plotly_chart(fig1)
 
        fig2 = px.scatter(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        st.plotly_chart(fig2)

    if choice == 'Fleet' and choice1== 'D':
        
        d1 = data[(data['VENDORGROUP']=='Fleet') & (data['LOCTYPE']=='D')]
 
        fig = px.histogram(d1,x=['CUSTSTATE'],color='CUSTCITY',labels = {'value':'States','Count':'Number Of Orders'},title='Number of Orders In Each State')
        st.plotly_chart(fig)
 
        fig0 = px.pie(d1,values='STOP',names='CUSTSTATE',title='Stops In Each State')
        st.plotly_chart(fig0)
 
        fig1 = px.bar(d1,x='CUSTSTATE',y='DELEVERY_DAY',color='STOP',title="Delivery Status For Each State")
        st.plotly_chart(fig1)
 
        fig2 = px.scatter(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        st.plotly_chart(fig2)

    if choice == 'Non Fleet' and choice1== 'O':
        
        d1 = data[(data['VENDORGROUP']=='Non-Fleet') & (data['LOCTYPE']=='O')]
 
        fig = px.histogram(d1,x=['CUSTSTATE'],color='CUSTCITY',labels = {'value':'States','Count':'Number Of Orders'},title='Number of Orders In Each State')
        st.plotly_chart(fig)
 
        fig0 = px.pie(d1,values='STOP',names='CUSTSTATE',title='Stops In Each State')
        st.plotly_chart(fig0)
 
        fig1 = px.bar(d1,x='CUSTSTATE',y='DELEVERY_DAY',color='STOP',title="Delivery Status For Each State")
        st.plotly_chart(fig1)
 
        fig2 = px.scatter(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        st.plotly_chart(fig2)
    
    
    if choice == 'Non Fleet' and choice1== 'D':
        
        d1 = data[(data['VENDORGROUP']=='Non-Fleet') & (data['LOCTYPE']=='D')]
 
        fig = px.histogram(d1,x=['CUSTSTATE'],color='CUSTCITY',labels = {'value':'States','Count':'Number Of Orders'},title='Number of Orders In Each State')
        st.plotly_chart(fig)
 
        fig0 = px.pie(d1,values='STOP',names='CUSTSTATE',title='Stops In Each State')
        st.plotly_chart(fig0)
 
        fig1 = px.bar(d1,x='CUSTSTATE',y='DELEVERY_DAY',color='STOP',title="Delivery Status For Each State")
        st.plotly_chart(fig1)
 
        fig2 = px.scatter(d1,x='COST', y='REVENUE',color='CUSTSTATE',title= 'Cost & Revenue In Each State')
        st.plotly_chart(fig2)







        

if choice == 'Profiling':
    
    data['ESTIMATED_DELIVARY_TIME'] = pd.to_datetime(data['ESTIMATED_DELIVARY_TIME'])
    data['ACTUAL_DELIVARY_TIME'] = pd.to_datetime(data['ACTUAL_DELIVARY_TIME'])
    profile_report = data.profile_report(minimal=True)
    st_profile_report(profile_report)
    
   

if choice == "MLAAS":  
    st.title('Logistic Classification Prediction') 

    dff = df
    dff.drop(['ID','ESTIMATED_DELIVARY_TIME','ACTUAL_DELIVARY_TIME','COST','REVENUE','PROFIT','DELEVERY_DAY','CustCity','CustServiceFlag',
                               'ShipperCity','ShipperState','ShipperLiveDropPoolFlag','OrigRampRegionCode',
                                     'OrigGroundRegionCode','OrigRSCRegionCode','ConsigneeCity','ConsigneeState','ConsigneeLiveDropPoolFlag',
                                     'DestRampRegionCode','DestGroundRegionCode','DestRSCRegionCode','RampCity','RampState','RampArea','VendorGroup',
                               'PacerControlled'],axis=1,inplace=True)
    


    dff = df[df.OnTimeFlag=='Success'].iloc[0:500]
    dff1=df[df.OnTimeFlag=='Fail']
    fdf=pd.concat([dff,dff1],axis=0)
    fdf.reset_index(inplace = True)
    fdf.drop('index',axis=1,inplace=True)

    label_encode_LocType = {value: key for key , value in enumerate(fdf["LocType"].unique())}
    fdf["LocType"] = fdf["LocType"].map(label_encode_LocType)

    # label_encode_Seq = {value: key for key , value in enumerate(fdf["Seq"].unique())}
    # fdf["Seq"] = fdf["Seq"].map(label_encode_Seq)

    # label_encode_Stop = {value: key for key , value in enumerate(fdf["Stop"].unique())}
    # fdf["Stop"] = fdf["Stop"].map(label_encode_Stop)

    # label_encode_SMPFlag = {value: key for key , value in enumerate(fdf["SMPFlag"].unique())}
    # fdf["SMPFlag"] = fdf["SMPFlag"].map(label_encode_SMPFlag)

    label_encode_OrderStatusCode = {value: key for key , value in enumerate(fdf["OrderStatusCode"].unique())}
    fdf["OrderStatusCode"] = fdf["OrderStatusCode"].map(label_encode_OrderStatusCode)

    label_encode_GroundRegionCode = {value: key for key , value in enumerate(fdf["GroundRegionCode"].unique())}
    fdf["GroundRegionCode"] = fdf["GroundRegionCode"].map(label_encode_GroundRegionCode)

    label_encode_RSCRegionCode = {value: key for key , value in enumerate(fdf["RSCRegionCode"].unique())}
    fdf["RSCRegionCode"] = fdf["RSCRegionCode"].map(label_encode_RSCRegionCode)

    label_encode_CustState = {value: key for key , value in enumerate(fdf["CustState"].unique())}
    fdf["CustState"] = fdf["CustState"].map(label_encode_CustState)

    label_encode_CustLiveDropPoolFlag = {value: key for key , value in enumerate(fdf["CustLiveDropPoolFlag"].unique())}
    fdf["CustLiveDropPoolFlag"] = fdf["CustLiveDropPoolFlag"].map(label_encode_CustLiveDropPoolFlag)
    
    fdf['OnTimeFlag'] = np.where(fdf['OnTimeFlag'] == 'Success' , 0,1)

    X=fdf.drop('OnTimeFlag',axis=1)
    Y=fdf['OnTimeFlag']

    X_train,X_test,y_train,y_test = train_test_split(X, Y,test_size = 0.2,random_state=10)
    scaler = StandardScaler()
    scaler.fit(X_train)
    transform = scaler.transform(X_train)
    scalar_train = pd.DataFrame(transform)
    scalar_train.head()

    le = LabelEncoder()
    y_train = le.fit_transform(y_train)

    cl_xgb=xgb.XGBClassifier()
    cl_xgb.fit(X_train,y_train,verbose=True,early_stopping_rounds=10,eval_set=[(X_test,y_test)])


    with st.form(key='my_form'):
        LocType = st.selectbox("LocType",['O','D']) 
        Seq = st.selectbox("Seq",[1,2,3,4,5])
        Stop = st.selectbox("Stop",[1,2,3,4])
        SMPFlag = st.selectbox("SMPFlag",[0,1])
        OrderStatusCode = st.selectbox("OrderStatusCode",['F', 'L', 'Y', 'S', 'A', 'C']) 
        GroundRegionCode = st.selectbox("GroundRegionCode",['SOCA', 'OHV', 'CNMEX', 'EAST', 'SE', 'SW', 'CANADA', 'PNW','NEMEX', 'NOCA', 'SOMEX', 'NWMEX'])
        RSCRegionCode = st.selectbox("RSCRegionCode",['WESTRSC', 'NORRSC', 'MEXIRSC', 'SOURSC'])

        CustState = st.selectbox("CustState",['CA', 'OH', 'GJ', 'VA', 'JA', 'GA', 'TX', 'BC', 'IL', 'IN', 'SC',
        'WA', 'PA', 'MD', 'NL', 'AL', 'AR', 'OR', 'CT', 'FL', 'WI', 'NJ',
        'NC', 'ON', 'OK', 'MO', 'MI', 'TM', 'TN', 'SL', 'NY', 'KY', 'CU',
        'EM', 'NH', 'WV', 'MS', 'LA', 'NV', 'IA', 'HG', 'MA', 'KS', 'RI',
        'QE', 'NM', 'DC', 'VT', 'MN', 'UT', 'CI', 'AZ', 'DF', 'AG', 'CO',
        'DE', 'TL', 'ID', 'ZA', 'PB', 'QC', 'AB', 'ME', 'NB'])
        CustLiveDropPoolFlag = st.selectbox("CustLiveDropPoolFlag",['P', 'D', 'L'])

        submit_button = st.form_submit_button(label ='Predict')
    if submit_button:
        d = {'LocType':label_encode_LocType[LocType],
            'Seq':Seq,
            'Stop':Stop,
            'SMPFlag':SMPFlag,   
            'OrderStatusCode':label_encode_OrderStatusCode[OrderStatusCode],
            'GroundRegionCode':label_encode_GroundRegionCode[GroundRegionCode],
            'RSCRegionCode':label_encode_RSCRegionCode[RSCRegionCode],
    
            'CustState':label_encode_CustState[CustState],
            'CustLiveDropPoolFlag':label_encode_CustLiveDropPoolFlag[CustLiveDropPoolFlag]
            }

        dff = pd.DataFrame(d,index = [0])
    # print(dff)
    # print(X[:15])
    # print(cl_xgb.predict(X))
        predictions = cl_xgb.predict(dff[:1])
        print(predictions[0])
        
        if predictions[0]==0:
                st.write("SUCCESS :sunglasses:")
        else:
                st.write("FAIL :cry:")
        











if choice == 'Demand Forecasting':
    centered_title = """
        <div style="display: flex; justify-content: center;">
            <h2 style="color: black;">Demand Forecasting</h2>
        </div>
    """
    st.markdown(centered_title, unsafe_allow_html=True)
    st.dataframe(fdata)

    # a,b,c = st.tabs(['Annually','Halfyearly','Quaterly']) 

    
    # fdata = {
    # 'Date': pd.date_range(start='30-11-2002', end='31-10-2023', freq='D'),
    
    #  }
    # df = pd.DataFrame(fdata)

# Streamlit app
   
    # period = st.selectbox('Select Period', ['Annually', 'Half-Yearly', 'Quarterly'])
    a,b,c = st.tabs(['Annually','Halfyearly','Quaterly']) 

    # with a:
    #  st.dataframe(fdata)
   
    

        
    # with b:
    #  if st.button('Half-Yearly'):
    #     st.write(df.groupby([df['Date'].dt.year, df['Date'].dt.Date // 6]).sum())
    # with c:
    #  if st.button('Quarterly'):
    #     st.write(df.groupby([df['Date'].dt.year, df['Date'].dt.Date]).sum())


    

    