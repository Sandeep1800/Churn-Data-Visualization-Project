import streamlit as st
import pandas as pd

data =st.file_uploader('Upload the file')

if data:
    df = pd.read_csv(data)
    st.dataframe(df)

    st.title('Geopraphy')

    a,b,c=st.tabs(['Spain','France','Germany'] )
    s =df[df['Geography']=='Spain']
    f =df[df['Geography']=='France']
    g =df[df['Geography']=='Germany']
   
    with a:
        st.write('hello')
        st.dataframe(s)
    with b:
        st.write('hello')
        st.dataframe(f)
    with c:
        st.write('hello')
        st.dataframe(g)
    st.title ('Gender')
    
    choice = st.selectbox("Gender", [ "Male", "Female"])
    if choice == "Male":
        male = df[df['Gender']=='Male']
        st.dataframe(male)
    if choice == "Female":
        female = df[df['Gender']=='Female']
        st.dataframe(female)
    
    st.title('Image in streamlit' )
    st.image('img.jpg', caption="Brid on the Branch",width = 600)

    st.title('video in streamlit')
    video = open('star.mp4','rb')
    v_bytes = video.read()
    st.video(v_bytes)

    st.title('This is normal form')
    
    name= st.text_input('enter your name')
    age= st.number_input('enter your age')
    Email =st.text_input('enter youeEmail')
    Location= st.text_input('enter your location')
    number =st.number_input('enter mobile number')
    but =st.button('Submit')

    st.title('With st.form')
    with st.form(key='Login'):
        name= st.text_input('enter your name')
        age= st.number_input('enter your age')
        Email =st.text_input('enter youeEmail')
        Location= st.text_input('enter your location')
        number =st.number_input('enter mobile number')
        but =st.form_submit_button('Submit')
        

  



