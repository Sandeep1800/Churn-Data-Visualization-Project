# 
import streamlit as st
st.image(r'C:\Users\sande\OneDrive\Pictures\Screenshots\2019-05-04 (8).png', caption='Your Image Caption', use_column_width=True)

user_type = st.selectbox("Select user type", ["Student", "Faculty", "Admin"])

if user_type == "Student":
    st.title('Student Registration')
    Fn = st.text_input('First Name')
    Ln = st.text_input('Last Name')
    Gender = st.selectbox("Gender", [" ", "Male", "Female", "Other"])
    email = st.text_input("Email address")
    address = st.text_input('Address')
    phone_number = st.text_input("Enter your phone number")
    btn = st.button('submit')

elif user_type == "Faculty":
    st.title('Faculty Registration')
    branch = st.selectbox("Branch", [" ", "CSE", "IT", "Mec"])
    Fn = st.text_input('First Name')
    Ln = st.text_input('Last Name')
    Gender = st.selectbox("Gender", [" ", "Male", "Female", "Other"])
    email = st.text_input("Email address")
    address = st.text_input('Address')
    phone_number = st.text_input("Enter your phone number")
    btn = st.button('submit')
    if btn:
        st.text(Fn)

elif user_type == "Admin":
    st.title('Login page')
    un = st.text_input('Enter your Name')
    pwd = st.text_input('Enter your password')
    btn = st.button('submit')

    if btn:
        st.text(un)

