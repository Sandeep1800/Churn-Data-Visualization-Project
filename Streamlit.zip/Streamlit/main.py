import streamlit as st
import pandas as pd
import streamlit as st
import pandas as pd 
import snowflake.connector
from snowflake.sqlalchemy import URL




conn = snowflake.connector.connect(**st.secrets['snowflake'],use_openssl_only = False)
with conn.cursor() as cur:
    cur.execute('select * from churn_data')
    res = cur.fetchall()

    df = pd.DataFrame(res)
    st.dataframe(df)

#df = pd.read_csv('Churn_Modelling.csv')


with st.sidebar:
    st.image("GATE IRA LOGO.svg", width=200)
    st.markdown(' ')
    # st.title('Churn Data')
    st.markdown("<h1 style='text-align: left; color: #3498DB;'>Customer Churn Application</h1>", unsafe_allow_html=True)
    choice = st.radio('',['Data','MLAAS','About'])

    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    st.markdown(' ')
    
    # st.title('About Cogwise')
    st.markdown("<h1 style='text-align: left; color: #3498DB;'>About Cogwise</h1>", unsafe_allow_html=True)
    st.write("""
            We help enterprises reinvent and optimize business functions by establishing the right approach 
            to use generative AI and LLMs to accelerate business value and growth.


            """)


if choice == 'Data':
    # st.title("Customer Churn Data")
    st.markdown("<h1 style='text-align: center; color: #3498DB;'>Customer Churn Data</h1>", unsafe_allow_html=True)
    st.markdown('---')
    st.dataframe(df)

    a,b,c = st.tabs(['Spain','France','Germany'])

    s = df[df['Geography']=='Spain']
    f = df[df['Geography']=='France']
    g = df[df['Geography']=='Germany']

    with a:
        # st.write('you selectd tab1')
        st.dataframe(s)
    with b:
        # st.write('you selectd tab2')
        st.dataframe(f)
    with c:
        # st.write('you selectd tab3')
        st.dataframe(g)

    # st.title('Streamlit Selectbox')
    c = st.selectbox('Select Gender',('Male','Female'))
    if c == 'Male':
        male = df[df['Gender']=='Male']
        st.dataframe(male)

    if c == 'Female':
        female = df[df['Gender']=='Female']
        st.dataframe(female)

if choice == 'About':
    # st.title('What is Churn')
    st.markdown("<h1 style='text-align: left; color: #3498DB;'>What is Churn</h1>", unsafe_allow_html=True)
    c1,c2 = st.columns(2)

    with c1:
        st.write("""
Customer churn is one of the most important metrics for a growing business to evaluate. 
While it's not the happiest measure, it's a number that can give your company the hard 
truth about its customer retention.
            
It's hard to measure success if you don't measure the inevitable failures, too. 
While you strive for 100 percent of customers to stick with your company, that's simply unrealistic. 
That's where customer churn comes in.

""")
        
    with c2:
        st.image('churn_image.png',width=550)
    
    # st.markdown('---')
    # st.title('Benefits of Churn')
    st.markdown("<h1 style='text-align: left; color: #3498DB;'>Benefits of Churn</h1>", unsafe_allow_html=True)
    st.write("""
 
                1. Retention: Churn prediction helps companies to identify customers who are at risk of leaving, allowing them to take proactive measures to prevent the churn. This may include offering discounts, providing better customer service, or making product improvements.
 
                2. Cost savings: Acquiring new customers can be expensive, so retaining existing customers can save companies significant costs. By predicting churn, companies can focus on retaining their existing customers, rather than spending resources on acquiring new ones.
 
                3. Increased revenue: Retaining customers who are likely to churn can help to maintain revenue levels. In addition, identifying reasons for churn can help companies make improvements to their products or services, which can lead to increased revenue.
 
                4. Competitive advantage: Companies that use churn prediction can stay ahead of the competition by identifying potential problems before they become major issues. This can lead to a better customer experience, increased revenue, and improved brand reputation.
""")
    

if choice == "MLAAS":  
    st.title('Logistic Classification Prediction') 

    dff=data
    dff.drop(['ID','ESTIMATED_DELIVARY_TIME','ACTUAL_DELIVARY_TIME','COST','REVENUE','PROFIT','DELEVERY_DAY','CustCity','CustServiceFlag',
              'ShipperCity','ShipperState','ShipperLiveDropPoolFlag','OrigRampRegionCode','OrigGroundRegionCode','OrigRSCRegionCode','ConsigneeCity',
              'ConsigneeState','ConsigneeLiveDropPoolFlag','DestRampRegionCode','DestGroundRegionCode','DestRSCRegionCode','RampCity',
              'RampState','RampArea','VendorGroup','PacerControlled'],axis=1,inplace=True)
    


    dff=df[df.OnTimeFlag=='Success'].iloc[0:500]
    dff1=df[df.OnTimeFlag=='Fail']
    fdf=pd.concat([dff,dff1],axis=0)
    fdf.reset_index(inplace = True)
    fdf.drop('index',axis=1,inplace=True)

    label_encode_LocType = {value: key for key , value in enumerate(fdf["LocType"].unique())}
    fdf["LocType"] = fdf["LocType"].map(label_encode_LocType)

    # label_encode_Seq = {value: key for key , value in enumerate(fdf["Seq"].unique())}
    # fdf["Seq"] = fdf["Seq"].map(label_encode_Seq)

    # label_encode_Stop = {value: key for key , value in enumerate(fdf["Stop"].unique())}
    # fdf["Stop"] = fdf["Stop"].map(label_encode_Stop)

    # label_encode_SMPFlag = {value: key for key , value in enumerate(fdf["SMPFlag"].unique())}
    # fdf["SMPFlag"] = fdf["SMPFlag"].map(label_encode_SMPFlag)

    label_encode_OrderStatusCode = {value: key for key , value in enumerate(fdf["OrderStatusCode"].unique())}
    fdf["OrderStatusCode"] = fdf["OrderStatusCode"].map(label_encode_OrderStatusCode)

    label_encode_GroundRegionCode = {value: key for key , value in enumerate(fdf["GroundRegionCode"].unique())}
    fdf["GroundRegionCode"] = fdf["GroundRegionCode"].map(label_encode_GroundRegionCode)

    label_encode_RSCRegionCode = {value: key for key , value in enumerate(fdf["RSCRegionCode"].unique())}
    fdf["RSCRegionCode"] = fdf["RSCRegionCode"].map(label_encode_RSCRegionCode)

    label_encode_CustState = {value: key for key , value in enumerate(fdf["CustState"].unique())}
    fdf["CustState"] = fdf["CustState"].map(label_encode_CustState)

    label_encode_CustLiveDropPoolFlag = {value: key for key , value in enumerate(fdf["CustLiveDropPoolFlag"].unique())}
    fdf["CustLiveDropPoolFlag"] = fdf["CustLiveDropPoolFlag"].map(label_encode_CustLiveDropPoolFlag)
    
    fdf['OnTimeFlag'] = np.where(fdf['OnTimeFlag'] == 'Success' , 0,1)

    X=fdf.drop('OnTimeFlag',axis=1)
    Y=fdf['OnTimeFlag']

    X_train,X_test,y_train,y_test = train_test_split(X, Y,test_size = 0.2,random_state=10)
    scaler = StandardScaler()
    scaler.fit(X_train)
    transform = scaler.transform(X_train)
    scalar_train = pd.DataFrame(transform)
    scalar_train.head()

    le = LabelEncoder()
    y_train = le.fit_transform(y_train)

    cl_xgb=xgb.XGBClassifier()
    cl_xgb.fit(X_train,y_train,verbose=True,early_stopping_rounds=10,eval_set=[(X_test,y_test)])


    with st.form(key='my_form'):
        LocType = st.selectbox("LocType",['O','D']) 
        Seq = st.selectbox("Seq",[1,2,3,4,5])
        Stop = st.selectbox("Stop",[1,2,3,4])
        SMPFlag = st.selectbox("SMPFlag",[0,1])
        OrderStatusCode = st.selectbox("OrderStatusCode",['F', 'L', 'Y', 'S', 'A', 'C']) 
        GroundRegionCode = st.selectbox("GroundRegionCode",['SOCA', 'OHV', 'CNMEX', 'EAST', 'SE', 'SW', 'CANADA', 'PNW','NEMEX', 'NOCA', 'SOMEX', 'NWMEX'])
        RSCRegionCode = st.selectbox("RSCRegionCode",['WESTRSC', 'NORRSC', 'MEXIRSC', 'SOURSC'])

        CustState = st.selectbox("CustState",['CA', 'OH', 'GJ', 'VA', 'JA', 'GA', 'TX', 'BC', 'IL', 'IN', 'SC',
        'WA', 'PA', 'MD', 'NL', 'AL', 'AR', 'OR', 'CT', 'FL', 'WI', 'NJ',
        'NC', 'ON', 'OK', 'MO', 'MI', 'TM', 'TN', 'SL', 'NY', 'KY', 'CU',
        'EM', 'NH', 'WV', 'MS', 'LA', 'NV', 'IA', 'HG', 'MA', 'KS', 'RI',
        'QE', 'NM', 'DC', 'VT', 'MN', 'UT', 'CI', 'AZ', 'DF', 'AG', 'CO',
        'DE', 'TL', 'ID', 'ZA', 'PB', 'QC', 'AB', 'ME', 'NB'])
        CustLiveDropPoolFlag = st.selectbox("CustLiveDropPoolFlag",['P', 'D', 'L'])

        submit_button = st.form_submit_button(label ='Predict')
if submit_button:
        d = {'LocType':label_encode_LocType[LocType],
            'Seq':Seq,
            'Stop':Stop,
            'SMPFlag':SMPFlag,   
            'OrderStatusCode':label_encode_OrderStatusCode[OrderStatusCode],
            'GroundRegionCode':label_encode_GroundRegionCode[GroundRegionCode],
            'RSCRegionCode':label_encode_RSCRegionCode[RSCRegionCode],
    
            'CustState':label_encode_CustState[CustState],
            'CustLiveDropPoolFlag':label_encode_CustLiveDropPoolFlag[CustLiveDropPoolFlag]
            }

        dff = pd.DataFrame(d,index = [0])
    # print(dff)
    # print(X[:15])
    # print(cl_xgb.predict(X))
        predictions = cl_xgb.predict(dff[:1])
        print(predictions[0])
        
        if predictions[0]==0:
                st.write("SUCCESS :sunglasses:")
        else:
                st.write("FAIL :cry:")
