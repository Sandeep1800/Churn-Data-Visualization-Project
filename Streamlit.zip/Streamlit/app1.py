import streamlit as st 

# with st.sidebar:
#      st.title('Thois is side bar example')
#      st.text('hello World ')
#      st.text_input('enter name')
#      st.number_input('enter mob number')
# title = st.title('this is title of the page ')

with st.sidebar:
    choice =st.radio(' ',options=['login','Register','Data','coloums'])

if choice == 'login':
    st.title('Login page')
    un = st.text_input('Enter your Name')
    pwd = st.text_input('enter your password')
    btn = st.button('submit')
    st.multiselect("Buy", ["milk", "apples", "potatoes"])
    
        

if choice =='Register':
    st.title('Register ')
    un = st.text_input('Enter your Name')
    email = st.text_input('enter your email')
    phone = st.number_input('Enter your phone')
    loc = st.text_input('enter your Location')
    btn = st.button('submit')


if choice =='Data':
    import pandas as pd
    
    data = pd.read_csv(r'C:\Users\sande\Desktop\Streamlit\Churn_Modelling.csv')
    st.title('This is Your DataFrame')
    st.dataframe(data)

    st.title('This is your table')
    st.table(data.head(10))
    st.page_link("app1.py", label="Home")

if choice == 'coloums':
    c1,c2,c3 =st.columns(3)
    with c1:
        st.title('this is coloum 1')
        st.title('Login page')
        un = st.text_input('Enter your Name')
        pwd = st.text_input('enter your password')
        btn = st.button('submit')
        st.multiselect("Buy", ["milk", "apples", "potatoes"])
    with c2:
        st.title('this is coloum 2')
        st.title('Register ')
        un = st.text_input('Enter your Name',key='1')
        
       
        email = st.text_input('enter your email')
        phone = st.number_input('Enter your phone')
        loc = st.text_input('enter your Location')
        btn = st.button('submit',key='b')

    with c3:
        st.title('this is coloum 3')
      


    
