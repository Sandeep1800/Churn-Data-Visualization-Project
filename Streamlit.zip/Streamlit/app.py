import streamlit as st
# # st.title('sreamlit first class')

# # st.markdown('this is my next line')
# # st.header('this is header')
# # st.subheader('this is subheader')
# # a=10

# # st.write(a)
# # st.write('this is wrire')






# user_name= st.text_input('enter your user name')
# pwd = st.text_input('Enter your password')
# number = st.number_input('enter your age')
# btn = st.button('submit')

# if btn:
#     # # st.write(type(user_name))
#     # # st.write(type(pwd))
#     # st.write(type(number))
#     pass

# st.latex(r""" e^{i\pi} + 1 = 0 """)
# c=st.checkbox('click for code')


# if c:
#     st.code("""user_name= st.text_input('enter your user name')
# pwd = st.text_input('Enter your password')
# btn = st.button('submit')""")

st.title('Student registaration form')
name= st.text_input('enter your name')
age= st.number_input('enter your age')
Email =st.text_input('enter youeEmail')
Location= st.text_input('enter your location')
number =st.number_input('enter mobile number')
but =st.button('Submit')

if but:
    st.write(name)
    st.write(age)
    st.write(Email)
    st.write(Location)
    st.write(number)
    st.write(but)    